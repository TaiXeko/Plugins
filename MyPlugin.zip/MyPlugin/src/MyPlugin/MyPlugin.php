<?php

namespace MyPlugin;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class MyPlugin extends PluginBase{
	
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		switch($command->getName()){
			case "chich":
			if(!isset($args[0])){
			$sender->sendMessage("Chịch Không Bạn ! !");
			return true;
			}
		}
	}
}
		